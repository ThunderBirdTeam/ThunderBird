# ThunderBird
C# Part II Teamwork Project

 2 exception handlings to do
 Atleast 1 multy-dimensional array
 At least 3 one-dimensional arrays (1 more to do)
 At least 10 methods (separating the application’s logic)
 Provide documentation for your application (2-3 pages).
  
 o Team name and list of team members (including usernames from the student system)
 o Project explanation – describe your game 
 o The URL of your Git repository 
 
 Presentation (optional)  - in progress - finishing stage
